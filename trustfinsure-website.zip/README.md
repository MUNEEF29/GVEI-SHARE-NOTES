# Trust FinSure Accounting Website

This repository hosts the official website for **Trust FinSure Accounting** — an online bookkeeping, accounting, and taxation service.

## 🚀 How to Deploy on GitHub Pages

1. **Create a GitHub account** (if you don’t have one already) at [https://github.com](https://github.com).
2. **Create a new repository** named `trustfinsure-site` (or any name you like).
3. **Upload** the website files:
   - Click **Add file → Upload files**.
   - Upload your `index.html` file (and any other assets if needed).
   - Click **Commit changes**.
4. Go to **Settings → Pages** on your repository.
   - Under **Source**, select `Deploy from a branch`.
   - Select the **main branch** and the **root directory**.
   - Click **Save**.
5. After a few minutes, your site will be live at:
   ```
   https://yourusername.github.io/trustfinsure-site/
   ```

## 🌐 Custom Domain (Optional)

1. Buy a domain (e.g., `trustfinsure.com`) from GoDaddy, Namecheap, or another registrar.
2. In your repository → **Settings → Pages**, scroll to **Custom domain** and add your domain.
3. Update your DNS settings at your registrar:
   - Add a **CNAME record** pointing to `yourusername.github.io`.
   - Add **A records** pointing to GitHub’s IPs (if needed):
     ```
     185.199.108.153
     185.199.109.153
     185.199.110.153
     185.199.111.153
     ```
4. Wait a few hours for DNS propagation.

## 📁 Folder Structure
```
trustfinsure-site/
│
├── index.html   # Main website file
└── README.md    # This guide
```

## 💡 Tips
- To update your site, just edit `index.html` and **commit changes** — GitHub Pages updates automatically.
- Keep your content professional, clear, and SEO-friendly.

---
© 2025 Trust FinSure Accounting. Trusted finance. Assured results.
